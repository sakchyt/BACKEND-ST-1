import React from 'react'
import './About.css'

const About = () => {
  return (
    <div className='about'>
      <h1 style={{zIndex:'2',margin:'100px'}} >THIS IS THE ABOUT PAGE</h1>
    </div>
  )
}

export default About
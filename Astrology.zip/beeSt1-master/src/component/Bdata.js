const d = [
  {
    id: 1,
    title: "What is Javascript",
    content: `A high-level definition JavaScript is a scripting or programming 
      language that allows you to implement complex features on web pages —
       every time a web page does more than just sit there and display static
        information for you to look at — displaying timely content updates, 
        interactive maps, animated 2D/3D graphics, scrolling video jukeboxes,
         etc. — you can bet that JavaScript is probably involved. It is the 
         third layer of the layer cake of standard web technologies, two of 
         which (HTML and CSS) we have covered in much more detail in other
          parts of the Learning Area.A high-level definition JavaScript is a scripting or
           programming language that allows you to implement complex features on web pages — every time a web page does more than just sit there and display static information for you to look at — displaying timely content updates, interactive maps, animated 2D/3D graphics, 
          scrolling video jukeboxes, etc. — you can bet that JavaScript is probably involved. It is the third layer of the layer cake of standard web technologies, two of which (HTML and CSS) we have covered in much more detail in other parts of the Learning Area
          A high-level definition JavaScript is a scripting or programming language that allows you to implement complex features on web pages — every time a web page does more than just sit there and display static information for you to look at — displaying
           timely content updates, interactive maps, animated 2D/3D graphics, scrolling video jukeboxes, etc. — you can bet that JavaScript is probably involved. It is the third layer of the layer cake of standard web technologies, two of which (HTML and CSS) we have covered in much more detail in other parts of the Learning Area`,
    author: "Ram",
  },
  {
    id: 2,
    title: "What is Javascript",
    content:
      "A high-level definition JavaScript is a scripting or programming language that allows you to implement complex features on web pages — every time a web page does more than just sit there and display static information for you to look at — displaying timely content updates, interactive maps, animated 2D/3D graphics, scrolling video jukeboxes, etc. — you can bet that JavaScript is probably involved. It is the third layer of the layer cake of standard web technologies, two of which (HTML and CSS) we have covered in much more detail in other parts of the Learning Area.",
    author: "SitaRam",
  },
  {
    id: 3,
    title: "What is Javascript",
    content: "javascript is javascript",
    author: "Ram",
  },
  {
    id: 4,
    title: "What is Javascript",
    content: "javascript is javascript",
    author: "SitaRam",
  },
];
export default d;
